#!/bin/bash
DATE=$(date +%F)
BACKUP_DIR="/backups"

mkdir -p $BACKUP_DIR

tar -czf $BACKUP_DIR/nginx_backup_$DATE.tar.gz /etc/nginx/ /usr/share/nginx/html/

tar -tf $BACKUP_DIR/nginx_backup_$DATE.tar.gz > $BACKUP_DIR/nginx_backup_$DATE.log
